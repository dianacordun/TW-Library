window.onload=function(){
  var formular=document.getElementById("form2");


    function valideaza() {

        if( document.form2.Nume.value == "" ) {
            alert( "Vă rugăm să introduceți numele!" );
            document.form2.Nume.focus() ;
            return false;
        }
        var inputName=document.getElementById("nume");
        if (!(localStorage.getItem(inputName.value) === null))
        {
         document.getElementById("email").value=localStorage.getItem(inputName.value);
          alert("Bine ai revenit!");
          return true;
        }
        if( document.form2.Email.value == "" ) {
            alert( "Vă rugăm să introduceți emailul!" );
            document.form2.Email.focus() ;
            return false;
        }
        else {
        var mailformat = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

        var email = document.form2.Email.value;


        if(email.match(mailformat))
          {
          alert("Ai fost înregistrat cu succes!");
          document.form2.Email.focus();
           
          if (localStorage.getItem(inputName.value) === null) {
              var inputEmail= document.getElementById("email");
              localStorage.setItem(inputName.value, inputEmail.value);
          }
          return true;
          }
          else
          {
          alert("Vă rugăm să introduceți o adresă de email validă!");
          document.form2.Email.focus();
          return false;
          }
        }
    }

   formular.onsubmit=function (){
        event.preventDefault();
        return valideaza();
   }
}

