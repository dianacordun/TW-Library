window.onload=function ()
{
    setInterval(function(){ alert("Vă face ceva cu ochiul? Ne găsiți la adresa din pagina de contact!"); }, 15000);
}